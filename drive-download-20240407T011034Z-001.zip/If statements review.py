n = input("Enter a number: ")   #user enters a number n
n = int(n)                      #int(n) changes the number n into an int

if(n%2 == 0):                   #n%2 == 0 means that the number is even
    print(n + " is even.")        #print that it's even
else:
    print(n + " is odd.")         #if it's not even, it's odd so print that it's odd
