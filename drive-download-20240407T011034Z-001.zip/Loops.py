numbers = [5, 4, 3, 2, 1]

for x in numbers:
    print(x)
