animals = ["Elephant", "Giraffe", "Monkey", "Tiger", "Lion"]

while x in range(animals):
    print(x)
