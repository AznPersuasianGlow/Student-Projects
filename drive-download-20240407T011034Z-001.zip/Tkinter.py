import random   #import random module
from tkinter import*

#tk = Tk()

def whatsup():
    print("What's up")

#btn=Button(tk,text = "Please click me!",command = whatsup)
#btn.pack()

#canvas=Canvas(tk,width=500,height=500)
#canvas.pack()
#canvas.create_rectangle(10,10,50,50)

def rectangle(width,height,fill_color):
    x1=random.randrange(width)
    y1=random.randrange(height)
    x2=x1 + random.randrange(width)
    y2=y1 + random.randrange(height)
    canvas.create_rectangle(x1,y1,x2,y2,fill=fill_color)

#rectangle(500,500,'red')
#rectangle(500,500,'orange')
#rectangle(500,500,'yellow')
#rectangle(500,500,'green')
#rectangle(500,500,'blue')
#rectangle(500,500,'purple')

#root=Tk()
#myCanvas=Canvas(root)
#myCanvas.pack()

def create_circle(x,y,r,canvasName): #center coordinates, radius
    x0=x-r
    y0=y-r
    x1=x+r
    y1=y+r
    return canvasName.create_oval(x0,y0,x1,y1)

#create_circle(100,100,20,myCanvas)
#create_circle(50,25,10,myCanvas)
#root.mainloop()

tk=Tk()
canvas=Canvas(tk,width=400,height=400)
canvas.pack()

#canvas.create_text(150,100,text="Hello.")   #create text
#canvas.create_text(130,120,text="I'm blue now.",fill="blue")    #change text color
#canvas.create_text(150,150,text="Now I'm Times font.",font=("Times",20))    #change font

canvas.create_polygon(10,10,10,60,50,35)

def move_shape(event):
    canvas.move(1,5,0,)

canvas.bind_all('<KeyPress-Return>',move_shape)
