import time
timer=5

while timer>0:
    print(timer, "...")
    time.sleep(1)
    timer=timer-1

print("Liftoff!")
