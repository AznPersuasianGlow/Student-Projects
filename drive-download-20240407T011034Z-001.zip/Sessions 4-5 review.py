def RockPaperScissors():
    choice = input("Rock, paper, scissors, shoot!: ")

    while choice != "rock" and choice != "paper" and choice != "scissors":
        choice = input("That's not one of the choices. Try again: ")
        
    if choice == "rock":
        print("Scissors! Oh no you got me!")
    
    elif choice == "paper":
        print("Paper! Tie!")

    elif choice == "scissors":
        print("Rock! Gotcha!")

    print("Thanks for playing!")


RockPaperScissors()
