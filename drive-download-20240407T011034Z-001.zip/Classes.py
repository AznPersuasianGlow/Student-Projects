class Animals():
    pass

class Reptiles(Animals):
    def produce_eggs(self):
        print("I produce eggs.")
    def have_scales(self):
        print("I have scales.")

class Lizards(Reptiles):
    def find_insects(self):
        self.move()
        print("I've found an insect to eat!")
        self.eat_insect()

    def eat_insect(self):
        self.eat_insect()
    def wiggle_around(self):
        self.move()
        self.move()
        self.move()

lily = Lizards()
lily.wiggle_around()
