from tkinter import *
import sys
import time

def end_game(gameover):
    x=input("GAME OVER... Would you like to play again? Enter 'y' or 'n': ")
    if x== 'y':
        CYOA()
    else:
        sys.exit()

def end_game2(gameover2):
    x=input("b)NOTHING HAPPENS... Would you like to play again? Enter 'y' or 'n': ")
    if x== 'y':
        CYOA()
    else:
        sys.exit()

def invalid():
    x=input("b)Seems like you entered an ivalid character... Would you like to play again? Enter 'y' or 'n': ")
    if x== 'y':
        CYOA()
    else:
        sys.exit()

s=(" SNACK  ")
p=(" PILLS ")
k=(" KNIFE ")



def dead():
    tk=Tk()
    canvas= Canvas(tk, width=500, height=400)
    canvas.pack()
    canvas.create_text(200,120, text= "You are dead (✖╭╮✖) ", fill="red", font=("Comic sans", 15))
    canvas.create_text(255,150, text= "close tab to continue ", fill="red", font=("Comic sans", 10))
    tk.mainloop()

def win():
    tk=Tk()
    canvas= Canvas(tk, width=500, height=400)
    canvas.pack()
    canvas.create_text(200,120, text= "🙂", fill="red", font=("Comic sans", 15))
    canvas.create_text(255,150, text= "Congratulations you stayed alive", fill="red", font=("Comic sans", 10))
    tk.mainloop()

def deadend():
    tk=Tk()
    canvas= Canvas(tk, width=500, height=400)
    canvas.pack()
    canvas.create_text(200,120, text= "(×_×)", fill="red", font=("Comic sans", 40))
    canvas.create_text(225,250, text= "end of story, close tab to continue ", fill="red", font=("Comic sans", 10))
    tk.mainloop()

def coma():
    tk=Tk()
    canvas= Canvas(tk, width=500, height=400)
    canvas.pack()
    canvas.create_text(200,120, text= "You fell into a coma, next time, only take the required amouts of pills.", fill="red", font=("Comic sans", 40))
    canvas.create_text(225,250, text= "end of story, close tab to continue ", fill="red", font=("Comic sans", 10))
    tk.mainloop()
    
def CYOA():
    question0=input("You have been given a chance to go to go on a rocket and find a new species! Do you a) take the chance 'you only live once' OR b) not: ")
    print(question0)
    if question0 == ("a"):
        print("a) You pack your stuff and are now ready to go on the rocket!")
    if question0== ("b"):
        end_game2("gameover2")


    inventory0=input("View inventory 'y' or 'n' ")
    if inventory0== ("y"):
        print("inventory status: empty")
    if inventory0== ("n"):
        print(" ")

    print("Now you're in a rocket to find a new species, and you hear some weird noises. What do you do? ")

    question1=input(" a) go and check the weird noise  b) go back to get a snack: ")
    print(question1)
    if question1 == ("a"):
        print( "a)  You died, the rockets machinery was bitten by a mouse that had surprisingly not died during lift-off. When you tried to see what the problem was with the machine, the entire rocket exploded and then you died")
        dead()
        end_game("gameover")
    if question1 == ("b"):
        print("b) When you went back to get a snack, something exploded, thankfully you're safe because the control panel was in a different section. So you are alive.") 

    question2=input("After getting your snack do you, a) you decide to a get out of the room without eating your snack OR b) continue to eat your snack: " )
    while question2!= "a":
        print("a) You decide to a get out of the room without eating your snack OR b)continue to eat your snack: ")
        question2=input()
        
    question3=print(s+"is added into your inventory")
    question3=input("The part of the rocket that you are in is safe, so the rocket says that is going to use autopilot and go to the nearest planet. Now what to do a) go to the nearest seating station OR b) help the people around you: ")
    if question3 == ("b"):
        print ("b) YOU DIED, while you are helping people around you, the rocket gets into some turbulence and you hit your head on the wall cracking your head open and bleading to death.")
        dead()
        end_game("game over")
    if question3 == ("a"):
        print("a) You get to the seating area where you meet some of your friends, you feel a some turbulence but you are okay since you have your seatbelt on.")
    else:
        print("you didn't pick a valid letter")
        invalid()
        question3=input("The part of the rocket that you are in is safe, so the rocket says that is going to use autopilot and go to the nearest planet. Now what to do a) go to the nearest seating station OR b) help the people around you ")
    

    print()
    for x in range(2,7):
       print("1 hour passes by")
       print("...")
    print()
    print("5 hours have passed by")
    print(">poof<")
    question4=input("You finally reach the new planet do you a) open the door of the rocket so you can see the new planet to get some fresh air OR b) go back and double check everything ")
    if question4 == ("a"):
        print ("a) YOU DIED, Without checking anything, you open the door, letting the toxic air of the new planet into the rocket causing the ENTIRE CREW and yourself to die")
        dead()
        end_game("game over")
    if question4 == ("b"):
        print("b) You make sure that all of your gear is working and in place. Once you go outside all of your gear works fine because you have already made sure that eveyrthing was working properly")
    else:
        print("You didn't pick a valid letter")
        invalid()
        
    question5=input("After taking a stroll in the new planet, you discover a creature do you a) go up to it OR b) go away from it ")
    import time
    timer = 0
    while timer > 0:
        print(timer,"step")
        time.sleep(1)
        timer= timer -1
    if question5 == ("a"):
        print(" a) You go up to the creature. you notice that it has large eyes and is pretty shiny")
    elif question5== ("b"):
        print ("b) You can't see much since you are too far from the creature but you try your best to see. So do you... ")
        question50()
    else:
        print("You didn't pick a valid letter")
        invalid()
    question6=input("You also notice that the creature has slimy skin, what are you going to do? a) touch it with your suit on OR b) not touch it at all ")
    if question6 == ("a"):
        print ("a) When you touch it, the creatures slime goes through your suit killing you, since you have a hole in your suit and you sufficate due to lack of oxygen ")
        dead()
        end_game("game over")
    if question6 == ("b"):
        print ("b) Instead of touching it yourself, the creature runs up to you smothering its slime onto the suit, this makes your suit melt and your skin starts to burn, thankfully your friend notices and she brings you to the infirmary.")        
    else:
        print("You didn't pick a valid letter")
        invalid()
        
    question7=input("You wake up feeling a bit thirsty, you see that there is a glass of water right next to you. Do you a) grab the glass of water OR  b) wait for someone to get it for you. ")
    if question7 == ("a"):
        print( "a) glass= acquired")
        question70()
    if question7 == ("b"):
        print (" b) It takes a while, but you friend notices you on the hospital bed, they get you water and a pill to help with the pain.")

    
    print(p+"are added into your inventory ")
    inventory=input("open inventory 'y' or 'n'")
    if inventory== ("y"):
        print("(1)"+s+"(1)"+p)
        print("...closing inventory...")
    if inventory== ("y"):
        print(" ")
    question8=input("Do you a) consume the pill OR b) not consume the pill ")
    if question8 == ("a"):
        print( "a) You swallow the pill and feel a little drowsy, so do you")
    if question8 == ("b"):
        print( "b) YOU DIED you needed that pill to survive, without taking the pill you died from ' high cholesterol'")
        deadend()
        end_game("game over")
    question9=input(" a) fall asleep OR b) stay awake ")
    if question9==("a"):
        print (" *one nap later* ")
        print (" a) wake up with a mild burn around your neck area and face, you see the creature come into your room ")
    if question9==("b"):
        print ("b) You feel more tired by the minute, do you ")
    question10=input("a)take another pill OR b) do you try and fall asleep ")
    if question10==("b"):
        print (" *one nap later* ")
        print (" YOU DIED, you wake up with a mild burn around your neck area and face, you see the creature come into your room and then every thing goes black... ")
        dead()
        end_game("game over")
    if question10==("a"):
        print (" You take another pill so you feel even more dizzy. ")
    question11=input("a) do you a walk around the room OR b) stay put ")
    if question11==("b"):
        print(" b) YOU ARE ALIVE BUT NOT REALLY you stay there and fall into a deep sleep, because you took two pills you fall into a deep sleep.")
        coma()
    if question11==("a"):
        print ("a) you walk around and see a knife")
    question12=input("a) grab knife OR b) put knife in inventory ")
    if question12==("b"):
        print(k+"is added into your inventory")
    question13=input("a) go back to seat OR b) continue walking ")
    if question13==("a"):
        print("a) You go back to the bed and you lie down. a few minutes later, you hear some foot steps, looks like the creature has come to visit you.")
    if question13==("b"):
        print("b) You don't find anything new... so you go back to the bed and you lie down. a few minutes later, you hear some foot steps, looks like the creature has come to visit you.")
    question14=input("a) threaten it with things in your inventory b) let it come to you ")
    if question14==("a"):
        print("a) open inventory")
        print("(1)"+s+"(1)"+p+"(1)"+k)
    question15=input("(1)"+s+"(1)"+p+"(1)"+k+"(select letter 's', 'p', or 'k') ")
    if question15==("s"):
        print("the creature laughs and comes up to you and heals you!🎉")
        win()
    if question15==("p"):
        print("The creature laughs and comes up to you and heals you!🎉")
        win()
    if question15==("s"):
        print("YOU DIED the creature gets offended and hurts you even more, so then you die")
        dead()
        end_game("game over")
        
    if question14==("b"):
        print("The creature comes up to you and heals you!, it also says sorry for its past actions. 🎉")
        win()
    
        
    
    if question12==("a"):
        print("YOU DIED, You are so dizzy that you trip over your legs and then die from blood loss.")
        dead()
        end_game("game over")
    if question11==("b"):
        print(" b) YOU ARE ALIVE BUT NOT REALLY you stay there and fall into a deep sleep, because you took two pills you fall into a deep sleep.")
        coma()



def question50():
    question50=input("a) go up to it OR b) go back to the rocket OR c) open inventory ")
    if question50==("a"):
        question50a()
    elif question50==("b"):
        question50b()
    elif question50==("c"):
        question50c()
def question50a():
        print(" a) You go closer to creature. You notice that it has large eyes, big teeth and is pretty shiny")
def question50b():
        print ("b) You walk back to the rocket, slowly but surely you get there. But you do not realize that the creature is following you. (it follows you all the way to the rocket) Once you get into the rocket many of your crew members see the strange creature")
def question50c():
        print ("c) you have (1) " +s+ "in your inventory")
        question51()

def question51():
    question51=input("a) give snack, b) eat snack c) close inventory")
    if question51== ("a"):
        print (" a) YOU DIED, The creature eats the snack and makes a weird sound. it follows you and goes very close to you, it touches your suit and then your suit starts to melt. This causes you to sufficate due to the lack of oxygen ")
        dead()
        end_game("game over")
    if question51== ("b"):
        print ("YOU DIED the only way to eat the snack is by taking off your helmet, you forget that you are in a different planet so you die due to lack of oxygen.")
        dead()
        end_game("game over")
    if question51==("c"):
        print("...inventory closed")
        
def question70():
    question70=input("a) drink from glass or b) put it back ")
    if question70 == ("a"):
        print( "a) *drinking*")
        print("Your friend gives you a bottle of pills to help with the pain.")
    elif question70 == ("b"):
        print( "b) *putting glass back*")
        print( "b) YOU DIE While you are putting the glass of water back, your arm slips causing you to drop the glass, and fall off of the hospital bed while you fall off the bed you fall on top of the glass causing you to bleed, after a while your friend finds you dead on the floor")
        dead()
        end_game("game over")
    
    

CYOA()


