list=[1,2,3]
list1=[1,2]
list.append(list1)

print(list)
