clothes=["Shirt", "Pants", "Hat"]

for i in clothes:
    print(i)
    for j in clothes:
        print(j)
