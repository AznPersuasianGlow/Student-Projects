#def Moon():                                                 #defines function Moon()
#    weight = input("What is the weight of the object? ")    #inputs object weight
#    weight = float(weight)                                  #converts weight to float
#    mWeight = weight * 0.165                                #so we can multiply by 0.165 and store in mWeight
#    mWeight = str(mWeight)                                  #converts mWeight to a string
#    print("Its weight on the moon is " + mWeight + " lbs!") #so we can print it out in a string

#Moon()                                                      #call Moon()
    
def add(num1, num2):
    return num1+num2

def saysum():
    print("LOUD NOISES")

ans1 = input("I'm going to add 2 numbers together. Tell me what you want me to add: ")
ans2 = input("Now another: ")

num1 = int(ans1)
num2 = int(ans2)

print("The sum is ", add(num1,num2))
