class Unicorn:  #class
    animal = "unicorn"

    def __init__(self, fur, horn):  #instance variable
        self.fur = fur
        self.horn = horn

Ocean = Unicorn("Pink", "Gold") #create unicorn objects
Moon = Unicorn("Blue", "Silver")

print("Ocean's details:")
print("Ocean is a", Ocean.animal)
print('Breed: ', Ocean.fur)
print('Color: ', Ocean.horn)

print("\nMoon's details:")
print("Moon is a", Moon.animal)
print('Breed: ', Moon.fur)
print('Color: ', Moon.horn)
