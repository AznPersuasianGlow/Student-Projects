fish=0
worm=0
stork=2
dog=4
rabbit=4
monkey=4
snail=0

zerolegs=0
twolegs=0
fourlegs=0

animals=[fish, worm, stork, dog, rabbit, monkey, snail]

for i in animals:
    if animals[i]==0:
        zerolegs = zerolegs + 1

    elif animals[i]==2:
        twolegs = twolegs + 1

    elif animals[i]==4:
        fourlegs = fourlegs + 1

        str(zerolegs)
        str(twolegs)
        str(fourlegs)

print("There are " + zerolegs + " animals with 0 legs, " + twolegs + " animals with 2 legs, " + fourlegs + " animals with 4 legs.")
